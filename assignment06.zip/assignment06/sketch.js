/* Learn more about the ml5.js project: https://ml5js.org/
 * ml5.js license and Code of Conduct: https://github.com/ml5js/ml5-next-gen/blob/main/LICENSE.md
 *
 * SAMPLED this example demonstrates hand tracking on live video through ml5.handPose.
 * SAMPLED this example demonstrates face tracking on live video through ml5.faceMesh.
 */

// variables for tracking the hands
let handPose;
let capture;
let hands = [];

// variables for tracking the face
let faceMesh;
let video;
let faces = [];
let options = { maxFaces: 1, refineLandmarks: false, flipHorizontal: false };

// hat variables
let hats = [];
let fallingHats = [];
let selectedHat;

// eyes variables
let eyes = [];
let fallingEyes = [];
let selectedEyes;

// star variable
let star;

function preload() {
    // loading the handPose model
    handPose = ml5.handPose();

    // loading the faceMesh model
    faceMesh = ml5.faceMesh(options);

    // all hats loading
    hats = [
        loadImage("hat1.png"),
        loadImage("hat2.png"),
        loadImage("hat3.png"),
        loadImage("hat4.png"),
        loadImage("hat5.png")
    ];

    // all eyes loading
    eyes = [
        loadImage("googlyeyes1.png"),
        loadImage("googlyeyes2.png"),
        loadImage("googlyeyes3.png"),
        loadImage("googlyeyes4.png"),
        loadImage("googlyeyes5.png")
    ];

    // load the star for the finger tip
    star = loadImage("star.png");
}

function setup() {
    createCanvas(640, 480);

    // creating the video display and hiding it
    pixelDensity(1);
    capture = createCapture({
        video: {
            mandatory: {
                minWidth: 640,
                minHeight: 480,
                maxWidth: 640,
                maxHeight: 480
            }
        },
        audio: false
    });
    capture.hide();

    // detecting hands from the webcam video
    handPose.detectStart(capture, gotHands);

    // detecting faces from the webcam video
    faceMesh.detectStart(capture, gotFaces);

    // create random hats falling from the screen
    for (let i = 0; i < 5; i++) {
        fallingHats.push(new Hat());
    }

    // create random eyes falling from the screen
    for (let i = 0; i < 5; i++) {
        fallingEyes.push(new Eye());
    }
}

function draw() {
    imageMode(CORNER);

    // drawing the webcam video
    image(capture, 0, 0, width, height);

    // begin tracking the user's finger tips
    let fingertipX;
    let fingertipY;

    if (hands.length > 0) {
        // trying to take only the index finger and creating a small star to track it for the user
        fingertipX = hands[0].index_finger_tip.x;
        fingertipY = hands[0].index_finger_tip.y;

        if (star) {
            imageMode(CENTER);
            image(star, fingertipX, fingertipY, 20, 20);
        }
    }

    // the movement of the falling hats
    for (let i = fallingHats.length - 1; i >= 0; i--) {
        let hat = fallingHats[i];
        hat.update();
        hat.display();

        // checking for if the user touches the hat with their finger
        if (fingertipX && fingertipY && dist(fingertipX, fingertipY, hat.x + 25, hat.y + 25) < 25) {
            // if the user touches the hat, put the hat on the user's head
            selectedHat = hat.img; 

            fallingHats.splice(i, 1);
            break;
        }

        // if the hat goes off screen and is untouched, remove the hat from the array of falling hats
        if (hat.y > height) {
            fallingHats.splice(i, 1);
            // create a replacing hat
            fallingHats.push(new Hat());
        }
    }

    // the movement of the falling eyes
    for (let i = fallingEyes.length - 1; i >= 0; i--) {
        let eye = fallingEyes[i];
        eye.update();
        eye.display();

        // checking for if the user touches the eyes with their finger
        if (fingertipX && fingertipY && dist(fingertipX, fingertipY, eye.x + 25, eye.y + 25) < 25) {
            selectedEyes = eye.img; 
            fallingEyes.splice(i, 1); 
            break;
        }

        if (eye.y > height) {
            fallingEyes.splice(i, 1);
            fallingEyes.push(new Eye());
        }
    }

    // for when the hat is selected, tracking the face to put the hat above the forehead of the user
    if (faces.length > 0 && selectedHat) {
        let face = faces[0];
        console.log(face.faceOval.x, face.faceOval.y);
        if (face.faceOval.x && face.faceOval.y) {
            console.log(face.faceOval);
            image(selectedHat, face.faceOval.x, (face.faceOval.y - face.faceOval.height) / 2, 200, 200);
        }
    }

    console.log("eye2");
    // Track face and place the selected eyes
    if (faces.length > 0 && selectedEyes) {
        let face = faces[0];
        if (face.leftEye.x > 0 && face.rightEye.x > 0 && face.leftEye.y > 0 && face.rightEye.y > 0) {
            let centerEyeX = (face.leftEye.x + face.rightEye.x) / 2;
            let centerEyeY = (face.leftEye.y + face.rightEye.y) / 2;
            image(selectedEyes, centerEyeX - selectedEyes.width / 2, centerEyeY - selectedEyes.height / 2, 150, 75);
        }
    }
}

// Callback function for when handPose outputs data
function gotHands(results) {
    // save the output to the hands variable
    hands = results;
}

// Callback function for when faceMesh outputs data
function gotFaces(results) {
    faces = results;
}

class Hat {

    constructor() {
        this.img = random(hats);
        this.x = random(width - 50);
        this.y = random(-100, -50);
        this.speed = random(2, 5);
    }
    update() {
        this.y += this.speed;
    }
    display() {
        image(this.img, this.x, this.y, 50, 50);
    }
}

class Eye {

    constructor() {
        this.img = random(eyes);
        this.x = random(width - 50);
        this.y = random(-100, -50);
        this.speed = random(2, 5);
    }
    update() {
        this.y += this.speed;
    }
    display() {
        image(this.img, this.x, this.y, 50, 50);
    }
}