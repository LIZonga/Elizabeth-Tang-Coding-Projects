//creating treasures
let treasure1,treasure2;

//creating background
let backgroundSlow,backgroundFast;

//creating sound
let bounceSound,collectSound,lossSound;

function preload(){
    treasure1 = loadImage("images/treasure.png");
    treasure2 = loadImage("images/treasure.png");
    backgroundSlow = loadImage("images/background.png");
    backgroundFast = loadImage("images/foreground.png");
    bounceSound = loadSound("sounds/boing.mp3");
    collectSound = loadSound("sounds/collect.mp3");
    lossSound = loadSound("sounds/loss.mp3");
}

//treasure1 variables
let treasure1X = 50;
let treasure1Y = 150;
let treasure1SpeedX = 3;
let treasure1Angle = 0;

//treasure2 variables
let treasure2X = 450;
let treasure2Y = 50;
let treasure2SpeedX = -3;
let treasure2Angle = 0;

//paddle variables
let paddleX = 250;
let paddleY = 480;
let paddleWidth = 100;
let paddleHeight = 20;

//ball variables
let ballX = 250;
let ballY = 30;
let ballSpeedX = 0;
let ballSpeedY = 0;

//backgroundFast variables
let posFast1 = 0;
let posFast2 = -1 * 500;
let speed1 = 2;

//backgroundSlow variables
let posSlow1 = 0;
let posSlow2 = -1 * 500;
let speed2 = 1;

//making the ball turn different colors
let r = 255;
let g = 200;
let b = 100;

let rSpeed = 2;

//tracking when the game is playing or not for the mouse button
let play = false;

//tracking the ball's initial speed
let ballStart = false;

//tracking the score of the game
let score = 0;

function setup() {
    //creating the background
    createCanvas(500,500);
    background(0);

    //randomizing the speed of the ball, no "0" speeds
    resetBall();
}

function draw() {
    background(0);
    
    //changing color speed
    r = (r+rSpeed);
    if (r > 255 || r < 0) {
        rSpeed *= -1;
    }
    
    //backgroundSlow movement
    image(backgroundSlow,0,posSlow1);
    image(backgroundSlow,0,posSlow2);
    posSlow1 += speed2;
    posSlow2 += speed2;

    if (posSlow1 >= height) {
        posSlow1 = posSlow2 - backgroundSlow.height;
    }
    
    if (posSlow2 >= height) {
        posSlow2 = posSlow1 - backgroundSlow.height;
    }
    
    //backgroundFast movement
    image(backgroundFast,0,posFast1);
    image(backgroundFast,0,posFast2);
    posFast1 += speed1;
    posFast2 += speed1;

    if (posFast1 >= height) {
        posFast1 = posFast2 - backgroundFast.height;
    }
    
    if (posFast2 >= height) {
        posFast2 = posFast1 - backgroundFast.height;
    }
    
    //make the paddle
    fill(128);
    rect(paddleX,paddleY,paddleWidth,paddleHeight);
    
    //show the score count
    fill(255);
    textSize(20);
    text("Points: "+score,20,35);
    
    //if the ball hits the left,right,and top walls (speeds up after each bounce)
    if (ballX > width - 25 || ballX < 25) {
        ballSpeedX *= -1;
        ballSpeedX *= 1.05;
        ballSpeedY *= 1.05;
        bounceSound.play();
    }
    if (ballY < 25) {
        ballSpeedY *= -1;
        ballSpeedY *= 1.05;
        ballSpeedX *= 1.05;
        bounceSound.play();
    }

    //allowing paddle to move left and right
    if (keyIsDown(65)) {
        paddleX -= 5;
    }
    if (keyIsDown(68)) {
        paddleX += 5;
    }

    //if the ball hits the paddle (secure if paddle has been hit) and reverses speed
    if (ballY + 25 >= paddleY && ballY + 25 <= paddleY + paddleHeight && ballX > paddleX && ballX < paddleX + paddleWidth) {
        ballSpeedY *= -1;
        ballSpeedY *= 1.05;
        ballSpeedX *= 1.05;
        bounceSound.play();

        let hitPaddle = (ballX - paddleX) / paddleWidth;
        //first determine the change in ball speedx, call map
        let speedChange = map(hitPaddle, 0, 1, 0.5, 1.5);
        //multiply ball speedx by this value
        ballSpeedX *= speedChange;
    }

    //resetting the ball if it goes out of bounds
    if (ballY > height + 30) {
        lossSound.play();
        play = false;
        resetBall();
    }

    paddleX = constrain(paddleX,0,width - paddleWidth);

    //moving treasures (1 is L to R) and (2 is R to L)
    treasure1Angle += 2;
    treasure2Angle += 4;

    push();
    translate(treasure1X + 25, treasure1Y +25);
    rotate(radians(treasure1Angle));
    imageMode(CENTER);
    image(treasure1, 0, 0,50,50);
    pop();

    treasure1X += treasure1SpeedX;

    if (treasure1X > width) {
        treasure1X = 0;
        treasure1Y = random(100,400);
    }

    push();
    translate(treasure2X + 25, treasure2Y +25);
    rotate(radians(treasure2Angle));
    imageMode(CENTER);
    image(treasure2, 0, 0,50,50);
    pop();

    treasure2X += treasure2SpeedX;

    if (treasure2X < -50) {
        treasure2X = width + 50;
        treasure2Y = random(100,400);
    }

    //counting score when ball touches a treasure
    if (dist(ballX, ballY, treasure1X + 25, treasure1Y + 25) < 40) {
        collectSound.play();
        treasure1X = -100; 
        treasure1Y = random(100, 400); 
        score++;
    }

    //looping the second treasure
    if (dist(ballX, ballY, treasure2X + 25, treasure2Y + 25) < 40) {
        collectSound.play(); 
        treasure2X = -100;
        treasure2Y = random(100, 400);
        score++;
    }

    //creating 3 visual borders(up,left,right)
    noStroke();
    fill(128);
    rect(0,0,500,10);
    rect(0,0,10,500);
    rect(490,0,10,500);

    //creating the ball that moves and bounces
    fill(r,g,b);
    ellipse(ballX,ballY,50,50);
    if (play){
        ballX += ballSpeedX;
        ballY += ballSpeedY;
    }
}

function resetBall() {
    ballX = 250;
    ballY = 30;

    if (play == false) {
        //changing the angle the ball goes
        let angle = Math.random() * Math.PI;
    
        //randomizing the speed of the ball, no "0" speeds
        let speed = random(1,7);
        ballSpeedX = speed * Math.cos(angle);
        ballSpeedY = speed * Math.sin(angle) * 1.5;
    
        ballStart = true;
        }

    play = false;

    score = 0;
}

function mousePressed(){
    if (play == false) {
        play = true;
    }
}