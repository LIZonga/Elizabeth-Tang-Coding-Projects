// variable to hold the A-Frame world
let world;

// variable for the user to feel for surrounding objects
let mazeModel;

let container1, container2;

// buffer for the texture
let buffer;
let texture;

// variables for the points
let points = 0;

// variables for the changing dynamic color
let bg = 255;
let number = -1;
			  		
function setup() {
   // no canvas needed
   noCanvas();
   
   // create a new VR World object
   world = new AFrameP5.World('VRScene');

   // create the edges of the world
   let wall1 = new AFrameP5.Box({
        x: -125,
        y: 2,
        z: 0,
        width: .5,
        height: 25,
        depth: 250,
        asset: "stonebrick",
        repeatX: 35,
        repeatY: 5,
        red: 8, green: 71, blue: 36
    });
    let wall2 = new AFrameP5.Box({
        x: 125,
        y: 2,
        z: 0,
        width: 1,
        height: 25,
        depth: 250,
        asset: "stonebrick",
        repeatX: 35,
        repeatY: 5,
        red: 8, green: 71, blue: 36
    });
    let wall3 = new AFrameP5.Box({
        x: 0,
        y: 2,
        z: -125,
        width: 250,
        height: 25,
        depth: .5,
        asset: "stonebrick",
        repeatX: 35,
        repeatY: 5,
        red: 8, green: 71, blue: 36
    });
    let wall4 = new AFrameP5.Box({
        x: 0,
        y: 2,
        z: 125,
        width: 250,
        height: 25,
        depth: .5,
        asset: "stonebrick",
        repeatX: 35,
        repeatY: 5,
        red: 8, green: 71, blue: 36
    });

    // add the walls to the world
    world.add(wall1);
    world.add(wall2);
    world.add(wall3);
    world.add(wall4);
   
    // create the head over display to keep track of scores and show instructions
    let hud = new AFrameP5.Plane({
        width: 2,
        height: .8,
        x: 1,
        y: 1,
        z: -1,
        red: 255, green: 255, blue: 255
    });
    world.addToHUD(hud);

    // add a points cointer into the hud
    let pointsText = new AFrameP5.Text({
        text: "Points: " + points,
        fontSize: 50,
        red: 0,
        green: 0,
        blue: 0
    });
    world.addToHUD(pointsText, 0.69, 0.79, -1);

    // the buffer and texture
    buffer = createGraphics(512, 512);
    buffer.background(128);
    texture = world.createDynamicTextureFromCreateGraphics(buffer);

    // create a plane to be the ground
    let ground = new AFrameP5.Plane({ 
        x: 0,
        y: -5,
        z: 0,
        width: 250,
        height: 250, 
        red: 150,
        green: 75, 
        blue: 0, 
        rotationX: -90, 
        metalness: 0.25,
        asset: "dirt",
        repeatX: 50,
        repeatY: 50,
    });
    // set the ground so that it is a 'solid'
    ground.tag.object3D.userData.solid = true;
    // add the plane to our world
    world.add(ground);

    // container to add a flying revolving object around the platform to see the maze from the top
    container1 = new AFrameP5.Container3D({
        x: 0, y: 0, z: -5,
    });
    world.add(container1);

    // add a platform for users to see the maze from the top
    let birdview = new AFrameP5.Sphere({
        x: 0, y: 100, z: 0,
        radius: 3,
        red: 255, green: 0, blue: 0,
        clickFunction: function(b) {
            world.teleportToObject(b);
        }
    });
    container1.add(birdview);

    // little indicator box to show that there is a big red button above
    let indicatorBox1 = new AFrameP5.Box({
        x: 7,
        y: 100,
        z: 0,
        width: 3,
        height: 3,
        depth: 3,
        red: 255,
        green: 255,
        blue: 0
    });
    container1.add(indicatorBox1);

    // container to add a flying revolving object around the platform to see the maze from the bottom
    container2 = new AFrameP5.Container3D({
        x: 0, y: 0, z: -5,
    });
    world.add(container2);

    // add a platform for users to see the maze from the bottom
    let floorview = new AFrameP5.Cone({
        x: 0, y: 0, z: 0,
        radiusBottom: 3,
        radiusTop: 0,
        height: 6,
        red: 0, green: 255, blue: 0,
        clickFunction: function(f) {
            world.teleportToObject(f);
        }
    });
    container2.add(floorview);

    // little indicator box to show that there is a big green button on the floor
    let indicatorBox2 = new AFrameP5.Box({
        x: 7,
        y: 0,
        z: 0,
        width: 3,
        height: 3,
        depth: 3,
        red: 255,
        green: 255,
        blue: 0
    });
    container2.add(indicatorBox2);

    // put the user on the ground
    world.setFlying(false);

    // // create donut item to collect using a for loop
    // for (let i = 0; i < 10; i++) {
    //     let donut = new AFrameP5.Torus({
    //         x: random(-122.5, 122.5),
    //         y: random(-4.5, 0),
    //         z: random(-122.5, 122.5),
    //         arc: 360,
    //         radius: 1, 
    //         tubularRadius: 1,
    //         rotationX: random(0, 360),
    //         rotationY: random(0, 360),
    //         rotationZ: random(0, 360),
    //         red: random(255),
    //         green: random(255), 
    //         blue: random(255),

    //         dynamicTexture: true,
    //         dynamicTextureWidth: 100,
    //         dynamicTextureHeight: 100,
    //         asset: texture,

    //         tickFunction: function(d) {
    //             d.spinY(2);
    //         },
    //         overFunction: function(d) {
    //             d.setScale(1.5, 1.5, 1.5);
    //         },
    //         leaveFunction: function(d) {
    //             d.setScale(1, 1, 1);
    //         },
    //         clickFunction: function(t) {
    //             if (points < 20) { 
    //                 world.remove(t);
    //                 points += 1;
    //                 pointsText.setText("Points: " + points);
    //             }
            
    //             // Check if points = 20
    //             if (points === 20) {
    //                 let feedback = new AFrameP5.Text({
    //                     x: 0, y: 0, z: -1,
    //                     text: "Congrats, you've collected all the items!",
    //                     fontSize: 1,
    //                     red: 0, green: 0, blue: 0
    //                 });
    //                 world.addToHUD(feedback);
    //             }
    //         }
    //     });
    //     world.add(donut);
    // }

    // create donut item to collect using OOP
    for (let i = 0; i < 10; i++) {
        let donut = new Donut(
            world,
            random(-122.5, 122.5),
            random(-4.5, 0),
            random(-122.5, 122.5),
            texture,
            pointsText
        );
        donut.addToWorld();
    }

    // create coin item to collect (very similar to the donuts)
    for (let i = 0; i < 10; i++) {
        let coin = new AFrameP5.GLTF({
            x: random(-122.5, 122.5),
            y: random(-4.5, 0),
            z: random(-122.5, 122.5),
            asset: "coin", 
            scaleX: 5,
            scaleY: 5,
            scaleZ: 5,
            tickFunction: function(c) {
                c.spinY(2);
            },
            overFunction: function(c) {
                c.setScale(6, 6, 6);
            },
            leaveFunction: function(c) {
                c.setScale(5, 5, 5);
            },
            clickFunction: function(s) {
                if (points < 20) { 
                    world.remove(s);
                    points += 1;
                    pointsText.setText("Points: " + points); 
                }
            
                // Check if points = 20, for the user to complete the game
                if (points === 20) {
                    let feedback = new AFrameP5.Text({
                        x: 0, y: 0, z: -1,
                        text: "Congrats, you've collected all the items!",
                        fontSize: 1,
                        red: 0, green: 0, blue: 0
                    });
                    world.addToHUD(feedback);
                }
            }
        });
        world.add(coin);
    }

    // create some large boxes for the user to go through to find donuts
    for (let i = 0; i < 50; i++) {
        let box = new AFrameP5.Box({
            x: random(-110.5, 110.5),
            y: 1,
            z: random(-110.5, 110.5),
            width: random(10, 20),
            height: random(10, 20),
            depth: random(10, 20),
            red: 128, green: 128, blue: 128
        });
        world.add(box);
    }

    // add the equirectangular sky image
    let sky = new AFrameP5.Sky({
        asset: "cloud"
    });
    world.add(sky);

    // create a signpost for instructions
    let signText = new AFrameP5.Text({
        x: .69, y: .69, z: -1,
        text: "Collect rings (10) and coins (10) to earn points! Press the green cone to view from the bottom and the red ball above to view from the top",
        fontSize: 1,
        red: 0, green: 0, blue: 0
    });
    world.addToHUD(signText);
}

function draw() {
    // have the yellow square to spin around the red circle
    container1.spinY(3);

    // have the yellow square to spin around the green cone
    container2.spinY(3);

    // create the texture where the background color dynamically changes color
    buffer.background(bg); 
    bg += number;
    
    if (bg <= 0 || bg >= 255) {
        number *= -1;
    };
        
}

// create class for all the donuts
class Donut {
    constructor(world, x, y, z, texture, pointsText) {
        this.world = world;
        this.pointsText = pointsText;

        // create the donut (copy and pasted from the previous for loop)
        this.donut = new AFrameP5.Torus({
            x: x,
            y: y,
            z: z,
            arc: 360,
            radius: 1, 
            tubularRadius: 1,
            rotationX: random(0, 360),
            rotationY: random(0, 360),
            rotationZ: random(0, 360),
            red: random(255),
            green: random(255), 
            blue: random(255),
            dynamicTexture: true,
            dynamicTextureWidth: 100,
            dynamicTextureHeight: 100,
            asset: texture,

            // how the donut would react while getting clicked on
            tickFunction: this.tickFunction.bind(this),
            overFunction: this.overFunction.bind(this),
            leaveFunction: this.leaveFunction.bind(this),
            clickFunction: this.clickFunction.bind(this)
        });
    }

    tickFunction(d) {
        d.spinY(2);
    }
    overFunction(d) {
        d.setScale(1.5, 1.5, 1.5);
    }
    leaveFunction(d) {
        d.setScale(1, 1, 1);
    }
    clickFunction(d) {
        // point system, if user collects all 20, they win the game
        if (points < 20) { 
            this.world.remove(d);
            points += 1;
            this.pointsText.setText("Points: " + points);
        }

        // check if points = 20, then show the user won
        if (points === 20) {
            let feedback = new AFrameP5.Text({
                x: 0, y: 0, z: -1,
                text: "Congrats, you've collected all the items!",
                fontSize: 1,
                red: 0, green: 0, blue: 0
            });
            this.world.addToHUD(feedback);
        }
    }
    addToWorld() {
        this.world.add(this.donut);
    }
}