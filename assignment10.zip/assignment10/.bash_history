cd databases
ls
sqlite3 to_do_list.db
