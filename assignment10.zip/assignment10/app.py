from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

# helper function to reduce repetition
def get_connection():
    conn = sqlite3.connect('databases/to_do_list.db')
    conn.row_factory = sqlite3.Row
    return conn

# our main route
@app.route('/')
def index():

    # open up a connection to our database
    conn = get_connection()

    # create a cursor object to execute our commands
    cursor = conn.cursor()

    # extract all records from the database
    sql = "SELECT id, title, status, priority, due_date FROM to_do_list_items ORDER BY priority, title"

    # run the query
    cursor.execute(sql)

    # fetch all the results into a Python list
    results = cursor.fetchall()

    # close the database connection
    conn.close()

    return render_template('index.html', items=results)

# /add - adds a new to-do list item
@app.route('/add', methods=['POST'])
def add():
    # grab the incoming data
    item_text = request.form.get('item_text', '')
    priority = request.form.get('priority', '2-Medium')
    due_date = request.form.get('due_date')

    # make sure we have some item text to work with
    if not item_text:
        return redirect('/?error=missing_item_text')

    # open up a connection to our database
    conn = get_connection()

    # create a cursor object to execute our commands
    cursor = conn.cursor()
    sql = "INSERT INTO to_do_list_items (title, status, priority, due_date) VALUES (?, ?, ?, ?)"

    # execute the query, passing the variable in as a parameter
    cursor.execute(sql, (item_text, 'pending', priority, due_date))

    # commit our changes
    conn.commit()

    # close the connection
    conn.close()

    # redirect back to the main route
    return redirect('/')

@app.route('/toggle_pending/<id>')
def toggle_pending(id):

    # open up a connection to our database
    conn = get_connection()

    # create a cursor object to execute our commands
    cursor = conn.cursor()
    sql = "UPDATE to_do_list_items SET status = ? WHERE id = ?"

    # execute the query, passing the variable in as a parameter
    cursor.execute(sql, ('pending', id))

    # commit our changes
    conn.commit()

    # close the connection
    conn.close()

    # redirect back to the main route
    return redirect('/')

@app.route('/toggle_completed/<id>')
def toggle_completed(id):

    # open up a connection to our database
    conn = get_connection()

    # create a cursor object to execute our commands
    cursor = conn.cursor()
    sql = "UPDATE to_do_list_items SET status = ? WHERE id = ?"

    # execute the query, passing the variable in as a parameter
    cursor.execute(sql, ('completed', id))

    # commit our changes
    conn.commit()

    # close the connection
    conn.close()

    # redirect back to the main route
    return redirect('/')

@app.route('/delete/<id>')
def delete(id):

    # open up a connection to our database
    conn = get_connection()

    # create a cursor object to execute our commands
    cursor = conn.cursor()
    sql = "DELETE FROM to_do_list_items WHERE id = ?"

    # execute the query, passing the variable in as a parameter
    cursor.execute(sql, (id,))

    # commit our changes
    conn.commit()

    # close the connection
    conn.close()

    # redirect back to the main route
    return redirect('/')

@app.route('/clear_completed', methods=['POST'])
def clear_completed():

    # open up a connection to our database
    conn = get_connection()

    # create a cursor object to execute our commands
    cursor = conn.cursor()

    # delete all tasks where status is 'completed'
    sql = "DELETE FROM to_do_list_items WHERE status = 'completed'"

    # run the query
    cursor.execute(sql)

    # commit our changes
    conn.commit()

    # close the connection
    conn.close()

    # redirect back to the main route
    return redirect('/')

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000)