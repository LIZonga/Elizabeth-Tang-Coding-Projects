let opacity = 255;

let temp;
let arrow;

// array for the arrow objections
let arrowGrid = [];

// array for the line of robots
let robotLine = [];

// the value of the robot's x and y position
let robotX;
let robotY;

// the value of the arrow's x and y position
let arrowX;
let arrowY;

function preload() {
  down = loadImage("images/arrow_down.png");
  left = loadImage("images/arrow_left.png");
  right = loadImage("images/arrow_right.png");
  up = loadImage("images/arrow_up.png");
}

function mousePressed() {
  for (let i = 0; i < arrowGrid.length; i++) {
    arrowGrid[i].checkClick();
  }
}

function setup() {
  createCanvas(800,600);
  background(128);

  imageMode(CENTER);

  robotX = 0;
  robotY = height / 2;
   
  // grid of all the arrows
  for (let gridX = 100; gridX < 750; gridX += width / 8) {
    for (let gridY = 75; gridY < 575; gridY += height / 8) {
        let pos = int(random(0,4));
        arrowGrid.push(new Arrow(gridX, gridY, pos));
    }
  }
}

function draw() {
  background(128);

  // draw the grid 
  for (let i = 0; i < arrowGrid.length; i++) {
    arrowGrid[i].display();
    arrowGrid[i].changeDirection();
  }

  // periodically create a Robot (1 per second)
  let newRobot = new Robot(robotX, robotY, "right");
  
  // if framecount is 60 per second, then mod 120 runs over 2 seconds
  if (frameCount % 90 == 0) {
    robotLine.push(newRobot);
  }

  // show these Robots
  for (let i = 0; i < robotLine.length; i++) {
    robotLine[i].move();
    robotLine[i].display();

    // remove the robot
    if (robotX > width) {
        robotLine.splice(i, 1);
      }
  }
}

class Robot {
  constructor (x, y, direction) {
    // initialize the variables
    this.x = x;
    this.y = y; 

    // headcolor and body color should be random
    this.headColor = color(random(255), random(255), random(255));
    this.bodyColor = color(random(255), random(255), random(255));

    // head size and body size should be a random value from 25 to 50 pixels with the body being bigger
    this.headSize = random(25, 50);
    this.bodySize = random(this.headSize + 5, this.headSize + 5);

    // create two eye types
    this.eyeType = random([0,1]);

    // initial direction
    this.direction = direction;

    // add speed
    this.Speedx = 1;
    this.Speedy = 1;

    // add thrust size
    this.thrustSize = this.bodySize / 2;
  }

  display() {
    // create the head
    noStroke();
    fill(this.headColor);
    rect(this.x, this.y, this.headSize, this.headSize);
    
    // create the body
    fill(this.bodyColor);
    // center the body to the head size, and put the body right below the head
    rect(this.x + (this.headSize - this.bodySize) / 2, this.y + this.headSize, this.bodySize, this.bodySize);

    // creating the visor eyes
    if (this.eyeType == 0) {
      fill(255);
      // visor eyes, start on the left-ish area of the head, slightly below the top part of the head, width is larger than the height
      rect(this.x + this.headSize / 6, this.y + this.headSize / 4, this.headSize / 1.5 , this.headSize / 4);
    } 
    // creating the two small eyes
    else if (this.eyeType == 1) {
      fill(255);
      // left eye, slightly below the top part of the head, the width is smaller than the height
      rect(this.x + this.headSize / 6, this.y + this.headSize / 4, this.headSize / 6, this.headSize / 4);
      // right eye, slightly below the top part of the head, the width is smaller than the height
      rect(this.x + this.headSize / 1.5, this.y + this.headSize / 4, this.headSize / 6, this.headSize / 4);
    }
  }

  move() {
    // half opacity is 128, then you slowly occilate between the frameCounts
    opacity = 128 + 128 * sin(frameCount * 0.1);

    if (this.direction == "up") {
      this.y -= this.Speedy;
      fill(255, 204, 0, opacity);
      // thinking about the center of the center of the head for X-Pos, then doing the bottom most side of the robot for Y-Pos
      ellipse(this.x + this.headSize / 2, this.y + this.headSize + this.bodySize, this.thrustSize, this.thrustSize);

    } else if (this.direction == "down") {
      this.y += this.Speedy;
      fill(255, 204, 0, opacity);
      // thinking about the center of the center of the head for X-Pos, then doing the top most side of the head for Y-Pos
      ellipse(this.x + this.headSize / 2, this.y, this.thrustSize, this.thrustSize);

    } else if (this.direction == "left") {
      this.x -= this.Speedx;
      fill(255, 204, 0, opacity);
      // thinking about the right most side of the body for X-pos (center the circle a little), then doing the center of it for Y-Pos
      ellipse(this.x + (this.bodySize / 1.1), this.y + this.bodySize + this.headSize / 2, this.thrustSize, this.thrustSize);

    } else if (this.direction == "right") {
      this.x += this.Speedx;
      fill(255, 204, 0, opacity);
      // thinking about the left most side of the body for X-pos (center the circle a little), then doing the center of it for Y-Pos
      ellipse(this.x - (this.bodySize / 6.1), this.y + this.bodySize + this.headSize / 2, this.thrustSize, this.thrustSize);
    }
  }
}

class Arrow {
  constructor(x, y, position) {
    this.x = x;
    this.y = y;

    // start the position at 0
    this.position = random([0, 1, 2, 3]);
  }

  display() {
    // show which position generates which arrow
    if (this.position == 0) {
      image(up, this.x, this.y);
    } else if (this.position == 1) {
      image(right, this.x, this.y);
    } else if (this.position == 2) {
      image(down, this.x, this.y);
    } else if (this.position == 3) {
      image(left, this.x, this.y);
    }
  }

  checkClick() {
    
    if (mouseX > this.x - 25 && mouseX < this.x + 25 && mouseY > this.y - 25 && mouseY < this.y + 25) {
      this.position += 1;
      this.position %= 4;
    }
  }

  changeDirection() {
    for (let i = 0; i < robotLine.length; i++) {
      let robot = robotLine[i];
      let distance = dist(robot.x + robot.bodySize / 2, robot.y + robot.headSize + robot.bodySize, this.x, this.y);
        
        /*
        line(robot.x, robot.y, arrow.x, arrow.y);
        text(int(distance), robot.x, robot.y);
        stroke(0);
        strokeWeight(2);
        */

        // if the robot the close posiiton to the arrow
        if (distance < 25) {
          if (this.position == 0) {
            robot.direction = "up";
          } else if (this.position == 1) {
            robot.direction = "right";
          } else if (this.position == 2) {
            robot.direction = "down";
          } else if (this.position == 3) {
            robot.direction = "left";
          }
        }
      }
  }
}
