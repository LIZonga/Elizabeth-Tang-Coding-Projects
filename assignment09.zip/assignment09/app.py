from flask import Flask, render_template, request, session, jsonify
import random
import json
import uuid
from datetime import datetime
import os

app = Flask(__name__)

# this is our app's secret key - it will be used to encode and "sign" cookies that we set on the client's computer
# this will prevent the user from tampering with the cookie and trying to impersonate another user
# for this to work this must remain secret, so we will store this string on the server
app.secret_key = os.environ.get("SECRET_KEY", b'super-secret-key-you-should-change-this')

# global list of previously used usernames
usernames = []

# global list of messages
messages = []

@app.route('/')
def index():
    return render_template('combined.html')

'''
ROUTE:      /login
METHOD:     POST
INPUT:      JSON payload containing 'username' (string)
PROCESSING: Validates the username (checks for blanks, non-alphabetic chars, and duplicates).
            If valid, stores the username in the global 'usernames' list and sets a signed session cookie.
OUTPUT:     JSON payload indicating 'success' or 'error' with a specific 'detail' message.
            {
                'status': 'success' | 'error',
                'detail': 'empty username' | 'invalid username' | 'duplicate username' | None
            }
'''

@app.route('/login', methods=["POST"])
def login():
    # get incoming data from the request object
    incoming_data = request.get_json(silent=True)

    # if the username variable is not present = error
    if not incoming_data or 'username' not in incoming_data:
        payload = {
            'status': 'error',
            'detail': 'empty username'
        }
        return jsonify(payload)

    # extract the username
    username = incoming_data['username'].strip().lower()

    # if the username is an empty string = error
    if len(username) == 0:
        payload = {
            'status': 'error',
            'detail': 'empty username'
        }
        return jsonify(payload)

    # if the username contains non-alphabetic characters = error
    if username.isalpha() == False:
        payload = {
            'status': 'error',
            'detail': 'invalid username'
        }
        return jsonify(payload)

    # if the username is a duplicate = error
    if username in usernames:
        payload = {
            'status': 'error',
            'detail': 'duplicate username'
        }
        return jsonify(payload)

    # username is valid! add it to our global list of usernames
    usernames.append(username)

    # set up a 'session' for the client
    session['username'] = username

    # generate a success message and send it to the client
    payload = {
        'status': 'success',
        'detail': None
    }
    return jsonify(payload)

'''
ROUTE:      /add_message
METHOD:     POST
INPUT:      JSON payload containing 'message' (string)
PROCESSING: Checks if the user is authenticated via session cookie.
            Validates the message (checks for existence and blanks).
            If valid, appends a dictionary {'username': user, 'message': text} to the global 'messages' list.
OUTPUT:     JSON payload indicating 'success' or 'error' with a specific 'detail' message.
            {
                'status': 'success' | 'error',
                'detail': 'unknown user' | 'empty message' | None
            }
'''

@app.route('/add_message', methods=['POST'])
def add_message():
    if 'username' not in session:
        payload = {
            'status': 'error',
            'detail': 'unknown user'
        }
        return jsonify(payload)

    # grab incoming data
    incoming_data = request.get_json(silent=True)

    # if the message variable is not present = error
    if not incoming_data or 'message' not in incoming_data:
        payload = {
            'status': 'error',
            'detail': 'empty message'
        }
        return jsonify(payload)

    # extract the message
    message = incoming_data['message']

    # if the message is an empty string = error
    if len(message.strip()) == 0:
        payload = {
            'status': 'error',
            'detail': 'empty message'
        }
        return jsonify(payload)

    # .strip() removes any accidental trailing spaces
    if message.strip() == '/roll':
        roll_result = random.randint(1, 6)
        message = f"rolled a {roll_result}! 🎲"

    # this runs for ALL messages — normal ones and transformed slash commands
    messages.append({
        'username': session['username'],
        'message': message,
        'time': datetime.now().strftime("%I:%M %p")
    })

    payload = {'status': 'success', 'detail': None}
    return jsonify(payload)

'''
ROUTE:      /get_messages
METHOD:     GET
INPUT:      URL Query String 'message_offset' (integer, defaults to 0)
PROCESSING: Extracts a slice of the global 'messages' list starting from the provided offset
            to the end of the list. This prevents the server from re-sending the entire chat history.
OUTPUT:     JSON payload containing the list of requested messages and the new total length of the list.
            {
                'messages': [ {'username': 'str', 'message': 'str'}, ... ],
                'total_messages': int
            }
'''

@app.route('/get_messages')
def get_messages():
    # get message 
    try:
        message_offset = int(request.args.get('message_offset', 0))
        if message_offset < 0:
            message_offset = 0
    except ValueError:
        message_offset = 0

    print("message offset:", message_offset)

    set_of_messages = messages[message_offset:]

    payload = {
        'messages': set_of_messages,
        'total_messages': len(messages)
    }

    # send messages dictionary
    return jsonify(payload)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000)