from flask import Flask, render_template, request, redirect, make_response
import json

# create the app
app = Flask(__name__)

# create an empty list to hold contact messages in memory
messages = []

try:
    with open('data/messages.json', 'r') as connection:
        data = connection.read()
        messages = json.loads(data) if data else []
except:
    messages = []

# home page
@app.route('/')
def index():

    # open and read the current count
    connection = open('data/visitors.txt', 'r')
    count = int(connection.read())
    connection.close()

    # add 1
    count = count + 1

    # save the new number back
    connection = open('data/visitors.txt', 'w')
    connection.write(str(count))
    connection.close()

    mode = request.cookies.get('mode', 'light')
    # read the font size cookie, default to medium if not set yet
    fontsize = request.cookies.get('fontsize', 'medium')
    
    return render_template('index.html', mode=mode, visitors=count, fontsize=fontsize)

# about page
@app.route('/about')
def about():
    mode = request.cookies.get('mode', 'light')
    fontsize = request.cookies.get('fontsize', 'medium')

    return render_template('about.html', mode=mode, fontsize=fontsize)

# preferances page
@app.route('/preferences')
def preferences():
    mode = request.cookies.get('mode', 'light')
    fontsize = request.cookies.get('fontsize', 'medium')

    return render_template('preferences.html', mode=mode, fontsize=fontsize)

# contact page (shows the form and the saved messages)
@app.route('/contact')
def contact():
    mode = request.cookies.get('mode', 'light')
    fontsize = request.cookies.get('fontsize', 'medium')
    status = request.args.get('status', '')

    return render_template('contact.html', mode=mode, status=status, messages=messages, fontsize=fontsize)

# submitting contacts (handles the form)
@app.route('/submit_contact', methods=['POST'])
def submit_contact():

    # grab each field from the form
    name = request.form.get('username')
    email = request.form.get('email')
    message = request.form.get('message')

    # if any field is empty, send them back with an error
    if not name or not email or not message:
        return redirect('/contact?status=error')

    # add the new message to the list
    messages.append({
        "name": name,
        "email": email,
        "message": message
    })

    # turn the list back into JSON text and save it to the file
    serialized = json.dumps(messages)
    connection = open('data/messages.json', 'w')
    connection.write(serialized)
    connection.close()

    return redirect('/contact?status=success')

# change modes (sets the cookie)
@app.route('/changemode/<mode>')
def changemode(mode):
    resp = make_response(redirect('/preferences'))
    resp.set_cookie('mode', mode)

    return resp

# projects page
@app.route('/projects')
def projects():

    # open the json file and read it
    connection = open('data/projects.json', 'r')
    projects_list = json.loads(connection.read())
    connection.close()

    mode = request.cookies.get('mode', 'light')
    fontsize = request.cookies.get('fontsize', 'medium')

    return render_template('projects.html', mode=mode, projects=projects_list, fontsize=fontsize)

# upvoting
@app.route('/upvote_project/<int:id>')
def upvote_project(id):

    # read the file
    connection = open('data/projects.json', 'r')
    projects_list = json.loads(connection.read())
    connection.close()

    # add 1 to the correct project using its position in the list
    projects_list[id]['votes'] = projects_list[id]['votes'] + 1

    # save it back
    connection = open('data/projects.json', 'w')
    connection.write(json.dumps(projects_list))
    connection.close()

    return redirect('/projects')

# downvoting
@app.route('/downvote_project/<int:id>')
def downvote_project(id):

    # read the file
    connection = open('data/projects.json', 'r')
    projects_list = json.loads(connection.read())
    connection.close()

    # only subtract if votes are above 0 so it never goes negative
    if projects_list[id]['votes'] > 0:
        projects_list[id]['votes'] = projects_list[id]['votes'] - 1

    # save it back
    connection = open('data/projects.json', 'w')
    connection.write(json.dumps(projects_list))
    connection.close()

    return redirect('/projects')

# changing the font size (second cookie)
@app.route('/changefont/<size>')
def changefont(size):
    resp = make_response(redirect('/preferences'))
    resp.set_cookie('fontsize', size)

    return resp

# journal page
@app.route('/journal')
def journal():

    # read all saved entries from the file
    connection = open('data/journal.json', 'r')
    entries = json.loads(connection.read())
    connection.close()

    mode = request.cookies.get('mode', 'light')
    fontsize = request.cookies.get('fontsize', 'medium')
    status = request.args.get('status', '')

    return render_template('journal.html', mode=mode, fontsize=fontsize, entries=entries, status=status)

# saving the journal
@app.route('/save_journal', methods=['POST'])
def save_journal():

    title   = request.form.get('title', '')
    content = request.form.get('content', '')

    # if either field is empty send them back with an error
    if not title or not content:
        return redirect('/journal?status=error')

    # read the existing entries
    connection = open('data/journal.json', 'r')
    entries = json.loads(connection.read())
    connection.close()

    # add the new entry to the list
    entries.append({
        'title': title,
        'content': content
    })

    # save it back
    connection = open('data/journal.json', 'w')
    connection.write(json.dumps(entries))
    connection.close()

    return redirect('/journal?status=success')

# skills page
@app.route('/skills')
def skills():
    mode = request.cookies.get('mode', 'light')
    fontsize = request.cookies.get('fontsize', 'medium')
    return render_template('skills.html', mode=mode, fontsize=fontsize)

# start the server
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000, debug=True)