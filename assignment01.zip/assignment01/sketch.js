function setup() {
    // set the background size of our canvas
    createCanvas(400, 400);
    background(135, 206, 235);
    
    push();
    translate (-30,0);

    // drawing the triangle body
    fill(255,255,224);
    stroke(255,165,0);
    strokeWeight(4);
    triangle(80, 300, 200, 100, 320, 300);

    // drawing the white part of the eyes
    fill(255,255,255);
    stroke(0)
    strokeWeight(.5);
    ellipse(150,250,40,40);
    ellipse(249,249,40,40);

    // drawing the black part of the eyes
    fill(0);
    stroke(255);
    ellipse(160,245,20,20);
    ellipse(260,245,20,20);

    // drawing the beak
    fill(255,165,0);
    stroke(255,165,0);
    triangle(180,250,218,250, 199,270);

    // drawing the feet
    fill(255,0,0);
    rect(140,300,30,20,10);
    rect(225,300,30,20,10);

    // drawing the egg
    fill(255);
    stroke(211,211,211);
    strokeWeight(4);
    ellipse(350,300,30,40)
    ellipse(340,300,30,40)
    ellipse(380,310,40,30)

    pop();
}

function draw() {

}