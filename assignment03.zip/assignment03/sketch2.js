function setup() {
    let canvas = createCanvas(700,200);
    background(135,206,235);
    canvas.parent("canvasContainer");
    canvas.elt.style.border = "5px solid lightgreen";
}

function draw() {
    background(135,206,235);
    
    //get the bestscore and current points
    let bestScore = localStorage.getItem("bestScore") ? parseInt(localStorage.getItem("bestScore")) : 0;
    let currentPoints = localStorage.getItem("currentPoints") ? parseInt(localStorage.getItem("currentPoints")) : 0;

    //calcululate the number of points needed to pass the high score
    let pointsNeeded = max(bestScore-currentPoints+1, 0);

    // Display the points needed to surpass the high score
    textSize(32);
    fill(0);
    stroke(0);
    textFont("Courier New");
    textAlign(CENTER, CENTER);
    text("Points Until NEW High Score: "+pointsNeeded,width/2, height/2);
}