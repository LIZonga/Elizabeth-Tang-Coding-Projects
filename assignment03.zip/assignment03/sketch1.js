//creating the chicken facing left
let chickenLeft;
let chickenX = 350;
let chickenY = 360;

//creating the chicken facing right
let chickenRight;

//which chicken facing is used
let facingRight = false;

//allowing the chicken to jump
let floorY = 360;
let jumpMode = false;
let jumpPower = 0;
let gravity = 0.3;

//creating clouds
let cloud1,cloud2;

//creating spikes
let spike1, spike2, spike3;

//creating eggs
let egg1, egg2, egg3, egg4, egg5;

//creating points
let points = 0;
let bestScore = localStorage.getItem("bestScore")?parseInt(localStorage.getItem("bestScore")):0;

//creating difficulty buttons
let easyButton, mediumButton, hardButton;

//creating sound effect for chicken
let bok;

//create falling variable
let falling = false;

function preload() {
    chickenLeft = loadImage("inspiration/chickenleft.png");
    chickenRight = loadImage("inspiration/chickenright.png");
    cloud1 = loadImage("inspiration/cloud.png");
    cloud2 = loadImage("inspiration/cloud.png");
    spike1 = loadImage("inspiration/spike.png");
    spike2 = loadImage("inspiration/spike.png");
    spike3 = loadImage("inspiration/spike.png");
    egg1 = loadImage("inspiration/egg.png");
    egg2 = loadImage("inspiration/egg.png");
    egg3 = loadImage("inspiration/egg.png");
    egg4 = loadImage("inspiration/egg.png");
    egg5 = loadImage("inspiration/egg.png");
    bok = loadSound("inspiration/chickensound.mp3");
}

//cloud1 variables
let cloud1X = 50;
let cloud1Y = 0;
let cloud1SpeedX = 1;

//cloud2 variables
let cloud2X = 650;
let cloud2Y = 150;
let cloud2SpeedX = -1.5;

//platform1 variables
let platform1X = 150;
let platform1Y = 300;
let platform1Width = 150;
let platform1Height = 20;
let platform1SpeedX = 3;

//platform2 variables
let platform2X = 400;
let platform2Y = 175;
let platform2Width = 150;
let platform2Height = 20;
let platform2SpeedX = -3;

//spike1 variables
let spike1X = 100;
let spike1Y = 380;
let spike1Hit = false;

//spike2 variables
let spike2X = 300;
let spike2Y = 380;
let spike2Hit = false;

//spike3 variables
let spike3X = 500;
let spike3Y = 380;
let spike3Hit = false;

//tracking when spikes are seen or not
let showSpikes = true;

//countdown timer variables
let countDown = 30;
let startTime;
let moreTime = 10;

//begin the state of the game
let state = "start";
let difficulty = null;

function setup() {
    let canvas = createCanvas(700,500);
    canvas.parent("canvasContainer");
    canvas.elt.style.border = "5px solid lightgreen";
    
    //make difficulty buttons
    easyButton = select("#easyButton");
    easyButton.mousePressed(() => setDifficulty("easy"));

    mediumButton = select("#mediumButton");
    mediumButton.mousePressed(() => setDifficulty("medium"));

    hardButton = select("#hardButton");
    hardButton.mousePressed(() => setDifficulty("hard"));

    //Start time
    startTime = millis();

    //use the "add more time" button to add more time for the use
    let addTimeButton = select("#addTime");
    addTimeButton.mousePressed(addMoreTime);

    //use the "restart game" button to restart the game
    let restartButton = select("#restartGame");
    restartButton.mousePressed(resetGame);

    points = 0;

    //egg variables
    egg1X = random(100, 600);
    egg1Y = random(100, 400);
    egg2X = random(100, 600);
    egg2Y = random(100, 400);
    egg3X = random(100, 600);
    egg3Y = random(100, 400);
    egg4X = random(100, 600);
    egg4Y = random(100, 400);
    egg5X = random(100, 600);
    egg5Y = random(100, 400);
}

function setDifficulty(level) {
    difficulty = level;
    state = "inPlay";
    startTime = millis();
    points = 0;

    //remove the difficulty level buttons after selection
    easyButton.hide();
    mediumButton.hide();
    hardButton.hide();

    //difficulty based on time
    if (level == "easy") {
        platform1SpeedX = 2;
        platform2SpeedX = -2;
        countDown = 90;
    } else if (level == "medium") {
        platform1SpeedX = 3;
        platform2SpeedX = -3;
        countDown = 60;
    } else if (level == "hard") {
        platform1SpeedX = 4;
        platform2SpeedX = -4;
        countDown = 30;
    }
}

function draw() {
    //make the background a light sky blue
    background(135,206,250);

    //showing the starting screen
    if (state == "start") {
        textSize(48);
        fill(0);
        textFont("Courier New");
        textAlign(CENTER, CENTER);
        text("Select Difficulty", width/2, height/2-20);
    } 
    else if (state == "inPlay") {

        //displaying the points
        textSize(24);
        fill(0);
        stroke(0);
        textFont("Courier New");
        textAlign(RIGHT,TOP);
        text("Points: "+points,width-20,20);

        //creating a timer that goes down from 60
        let goingTime = (millis()-startTime)/1000;
        let timeLeft = max(countDown-goingTime,0);
        
        //show timer
        textSize(24);
        fill(0);
        stroke(0);
        textFont("Courier New");
        textAlign(LEFT,TOP);
        text("Time: "+int(timeLeft)+"s",20,20);
        
        //make the green floor
        noStroke();
        fill(144,238,144);
        rect(0,425,width,80);

        platform1X += platform1SpeedX;

        if (platform1X <= 0 || platform1X + platform1Width >= width) {
            platform1SpeedX *= -1;
        }
        
        //show spikes every 5 seconds
        if (millis() % 5000 < 2500) {
            showSpikes = true;
        } else {
            showSpikes = false;
            spike1Hit = false;
            spike2Hit = false;
            spike3Hit = false;
        }

        if (showSpikes == true) {
            //make the spike1 on the floor
            image(spike1, spike1X, spike1Y, spike1.width/3, spike1.height/3);

            //make the spike2 on the floor
            image(spike2, spike2X, spike2Y, spike2.width/3, spike2.height/3);

            //make the spike3 on the floor
            image(spike3, spike3X, spike3Y, spike3.width/3, spike3.height/3);
        }

        //moving cloud1 from left to right side of the screen, random heights
        image(cloud1,cloud1X,cloud1Y,cloud1.width/6,cloud1.height/6);
        cloud1X += cloud1SpeedX;
        if (cloud1X > width) {
            cloud1X = -cloud1.width/6;
            cloud1Y = random (0,50);
        }

        //moving cloud2 from right to left side of the screen, random heights
        image(cloud2,cloud2X,cloud2Y,cloud2.width/8,cloud2.height/8);
        cloud2X += cloud2SpeedX;
        if (cloud2X < -cloud2.width/8) {
            cloud2X = width;
            cloud2Y = random (50,150);
        }
        //make a floating grass platform1
        strokeWeight(2);
        stroke(0, 100, 0);
        fill(144,238,144);
        rect(platform1X,platform1Y,platform1Width,platform1Height);

        platform2X += platform2SpeedX;

        if (platform2X <= 0 || platform2X + platform2Width >= width) {
            platform2SpeedX *= -1;
        }

        //make a floating grass platform2
        strokeWeight(2);
        stroke(0, 100, 0);
        fill(144,238,144);
        rect(platform2X,platform2Y,platform2Width,platform2Height);

        //put chicken in left facing mode by default, unless you are pressing the D key making facing right "true"
        if (facingRight == true) {
            image(chickenRight,chickenX,chickenY,chickenRight.width/1.5,chickenRight.height/1.5);
        }
        else {
            //put the chicken in the center of the grass to start
            image(chickenLeft,chickenX,chickenY,chickenLeft.width/1.5,chickenLeft.height/1.5);
        }

        //having the chicken move when a and d keys are pressed and changing the direction that the chicken is facing
        if (keyIsDown(65)) {
            chickenX -= 4;
            facingRight = false;
        }
        if (keyIsDown(68)) {
            chickenX += 4;
            facingRight = true;
        }
        if (keyIsDown(87) && jumpMode == false) {
            jumpMode = true;
            jumpPower = -9;
        }

        if (jumpMode == true && falling == false){
            chickenY += jumpPower;
            jumpPower += gravity;

            if (chickenY >= floorY) {
                chickenY = floorY;
                jumpMode = false;
                jumpPower = 0
                falling = false;
            }
        }
        
        //having the chicken touch platform1+2
        if (chickenY + chickenLeft.height/1.5 >= platform1Y-5 && chickenY + chickenLeft.height/1.5 <= platform1Y+5 && chickenX + chickenLeft.width/1.5 > platform1X && chickenX < platform1X + platform1Width && jumpPower >= 0) {
            chickenY = platform1Y - chickenLeft.height/1.5;
            jumpMode = false;
            jumpPower = 0;
            falling = false;
        } else if (chickenY + chickenLeft.height/1.5 >= platform2Y-5 && chickenY + chickenLeft.height/1.5 <= platform2Y+5 && chickenX + chickenLeft.width/1.5 > platform2X && chickenX < platform2X + platform2Width && jumpPower >= 0) {
            chickenY = platform2Y - chickenLeft.height/1.5;
            jumpMode = false;
            jumpPower = 0;
            falling = false;
        } else {
            falling = true;
            jumpPower += gravity;
            chickenY += jumpPower;

            if (chickenY >= floorY) {
                chickenY = floorY;
                jumpMode = false;
                jumpPower = 0
                falling = false;
            }
        }

        //having the chicken stay on platform1 after jumping on it
        if (chickenY + chickenLeft.height/1.5 == platform1Y && chickenX + chickenLeft.width/1.5 > platform1X && chickenX < platform1X + platform1Width) {
            chickenX += platform1SpeedX;
        }

        //having the chicken stay on platform2 after jumping on it
        if (chickenY + chickenLeft.height/1.5 == platform2Y && chickenX + chickenLeft.width/1.5 > platform2X && chickenX < platform2X + platform2Width) {
            chickenX += platform2SpeedX;
        }

        //having the chicken jump off of platform1 and platform2
        if ((chickenY + chickenLeft.height / 1.5 == platform1Y && (chickenX + chickenLeft.width/1.5 < platform1X || chickenX > platform1X + platform1Width)) || (chickenY + chickenLeft.height/1.5 == platform2Y && (chickenX + chickenLeft.width/1.5 < platform2X || chickenX > platform2X + platform2Width))) {
            jumpMode = true;
            jumpPower = 0;
        }
        
        chickenX = constrain(chickenX,-150,width-chickenLeft.width/3.25);

        //show eggs
        image(egg1, egg1X, egg1Y, egg1.width/10, egg1.height/10);
        image(egg2, egg2X, egg2Y, egg2.width/10, egg2.height/10);
        image(egg3, egg3X, egg3Y, egg3.width/10, egg3.height/10);
        image(egg4, egg4X, egg4Y, egg4.width/10, egg4.height/10);
        image(egg5, egg5X, egg5Y, egg5.width/10, egg5.height/10);

        //hit eggs
        checkHitEggs();
        hitSpikes();

        //game end when timer = zero
        if (timeLeft <= 0) {
            noLoop();

            //track the best score
            if (points > bestScore) {
                bestScore = points;
                localStorage.setItem("bestScore",bestScore);
            }
            state = "endGame";
        }
    }
    
    if (state == "endGame") {
        background(255, 255, 255, 100);
        fill(0);
        stroke(0);
        textSize(48);
        textAlign(CENTER, CENTER);
        text("Time's up!",width/2,height/2);

        textSize(32);
        text("Best Score: " + bestScore, width / 2, height / 2 + 50);
        }
}

function checkHitEggs() {
    let eggSize = egg1.width/10;

    //when the chicken hits the egg, then reset the position of the egg
    if (hitEgg(chickenX, chickenY, chickenLeft.width/1.5, chickenLeft.height/1.5, egg1X, egg1Y, eggSize, eggSize)) {
        egg1X = random(100, 600);
        egg1Y = random(100, 400);
        points += 1;
        
        //track the current points
        localStorage.setItem("currentPoints", points);
        
        if (bok.isLoaded()) {
            bok.play(0, 1, 1, 1, 0.5);
        }
    }

    if (hitEgg(chickenX, chickenY, chickenLeft.width/1.5, chickenLeft.height/1.5, egg2X, egg2Y, eggSize, eggSize)) {
        egg2X = random(100, 600);
        egg2Y = random(100, 400);
        points += 1;
          
        localStorage.setItem("currentPoints", points);
        
        if (bok.isLoaded()) {
            bok.play(0, 1, 1, 1, 0.5);
        }
    }

    if (hitEgg(chickenX, chickenY, chickenLeft.width/1.5, chickenLeft.height/1.5, egg3X, egg3Y, eggSize, eggSize)) {
        egg3X = random(100, 600);
        egg3Y = random(100, 400);
        points += 1;
          
        localStorage.setItem("currentPoints", points);
        
        if (bok.isLoaded()) {
            bok.play(0, 1, 1, 1, 0.5);
        }
    }

    if (hitEgg(chickenX, chickenY, chickenLeft.width/1.5, chickenLeft.height/1.5, egg4X, egg4Y, eggSize, eggSize)) {
        egg4X = random(100, 600);
        egg4Y = random(100, 400);
        points += 1;
          
        localStorage.setItem("currentPoints", points);
        
        if (bok.isLoaded()) {
            bok.play(0, 1, 1, 1, 0.5);
        }
    }

    if (hitEgg(chickenX, chickenY, chickenLeft.width/1.5, chickenLeft.height/1.5, egg5X, egg5Y, eggSize, eggSize)) {
        egg5X = random(100, 600);
        egg5Y = random(100, 400);
        points += 1;
          
        localStorage.setItem("currentPoints", points);
        
        if (bok.isLoaded()) {
            bok.play(0, 1, 1, 1, 0.5);
        }
    }
}

function hitSpikes() {
    if (showSpikes == false) return;

    let spikeWidth = spike1.width/3;
    let spikeHeight = spike1.height/3;

    //if the chicken hits the spike, lose 1 point
    if (hitEgg(chickenX, chickenY, chickenLeft.width/1.5, chickenLeft.height/1.5, spike1X, spike1Y, spikeWidth, spikeHeight)) {
        if (spike1Hit == false) {
            points = max(points-3,0);
            spike1Hit = true;
        }
    }
    else {
        spike1Hit = false;
    }
    if (hitEgg(chickenX, chickenY, chickenLeft.width/1.5, chickenLeft.height/1.5, spike2X, spike2Y, spikeWidth, spikeHeight)) {
        if (spike2Hit == false) {
            points = max(points-3,0);
            spike2Hit = true;
        }
    }
    else {
        spike2Hit = false;
    }
    if (hitEgg(chickenX, chickenY, chickenLeft.width/1.5, chickenLeft.height/1.5, spike3X, spike3Y, spikeWidth, spikeHeight)) {
        if (spike3Hit == false) {
            points = max(points-3,0);
            spike3Hit = true;
        }
    }
    else {
        spike3Hit = false;
    }
}

//chicken values(x1, y1, w1, h1) and egg values (x2, y2, w2, h2)
function hitEgg(x1, y1, w1, h1, x2, y2, w2, h2) {
    return x1 < x2 + w2 && x1 + w1 > x2 && y1 < y2 + h2 && y1 + h1 > y2;
}

function addMoreTime() {
    countDown += moreTime;
}

function resetGame() {
    window.location.reload();
}